-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 04-04-2019 a las 02:20:43
-- Versión del servidor: 5.1.36
-- Versión de PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `app_recept`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registros`
--

CREATE TABLE IF NOT EXISTS `registros` (
  `id_registro` int(11) NOT NULL AUTO_INCREMENT,
  `transporte` varchar(20) NOT NULL,
  `nombre_unidad` varchar(20) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` double NOT NULL,
  `descuento` double NOT NULL,
  `categoria` varchar(20) NOT NULL,
  PRIMARY KEY (`id_registro`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Volcar la base de datos para la tabla `registros`
--

INSERT INTO `registros` (`id_registro`, `transporte`, `nombre_unidad`, `cantidad`, `precio`, `descuento`, `categoria`) VALUES
(1, 'barco', 'barco1', 3, 50, 5, 'contenedor'),
(2, 'barco', 'barco2', 5, 20, 5, 'contenedor'),
(7, 'ferrocarril', 'ferrocarril2', 5, 60, 0, 'vagon'),
(4, 'barco', 'barco3', 6, 60, 1, 'contenedor'),
(6, 'ferrocarril', 'ferrocarril1', 6, 120, 0, 'vagon'),
(8, 'barco', 'barco4', 12, 50, 5, 'contenedor');
