<!DOCTYPE html>
<html>
<head>
     <link rel="icon" href="yin.ico">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FACTURAR</title>
<style type="text/css">
@import url("css/mycss.css");
</style>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body>
<div class="todo">
  
  <div id="cabecera">
       
        <center>
  <table>
 <tr>
    <td>Num de factura:</td>
    <td><input type="text" name="id_fac" value="" size="10"></td>
 </tr>
 <tr>
    <td>fecha de factura:</td>
    <td><input type="text" name="fecha_factura" value="<?php echo date("d-m-Y"); ?>" size="20"></td>
 </tr>
</table>
        </center>
      
      <?php
        include("nuevo_detalle.php");  
        ?>
  <div id="contenido">
  	<table   class="table table-bordered" style="margin: auto; width: 800px; border-collapse: separate; border-spacing: 10px 5px;">
  		<thead>
                        <th>TIPO DE TRANSPORTE</th>
  			<th>NOMBRE DE LA UNIDAD</th>
  			<th>CANTIDAD</th>
  			<th>PRECIO</th>
                        <th>DESCUENTO</th>
                        <th>CATEGORIA</th>
                       
  		</thead>
  		
  		
  		<?php
      include "conect/conexion.php";
      $sentencia="SELECT * FROM registros";
      $resultado=mysql_query($sentencia);
      while($filas=mysql_fetch_assoc($resultado))
      {
        echo "<tr>";
          echo "<td>"; echo $filas['transporte']; echo "</td>";
          echo "<td>"; echo $filas['nombre_unidad']; echo "</td>";
          echo "<td>"; echo $filas['cantidad']; echo "</td>";
          echo "<td>"; echo $filas['precio']; echo "</td>";
           echo "<td>"; echo $filas['descuento']; echo "</td>";
            echo "<td>"; echo $filas['categoria']; echo "</td>";
          
          echo "<td> <a href='eliminar_detalle.php?id_registro=".$filas['id_registro']."''><button type='button' class='btn btn-danger'>Eliminar</button></a> </td>";
        echo "</tr>";
      }

      ?>
  	</table>
      <form method="post" action="facturas/facturas.php">
          
    <button type="submit" class="btn btn-success">GENERAR FACTURA PDF </button>
  </div>
  
	<div id="footer">
  		
  	</div>

</div>
    
<input type="hidden" name="generar_factura" value="true">

</body>
</html>