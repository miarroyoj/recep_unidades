<?php
if ($_POST["generar_factura"] == "true")
      
{

   //Recibir detalles de factura
$id_factura = $_POST["id_factura"];
$fecha_factura = $_POST["fecha_factura"];
    
$archivo="factura-$id_factura.pdf";
require('fpdf.php');
$pdf = new FPDF();
$pdf->Cell(0,10,'Page '.$pdf->PageNo().'/{nb}',0,0,'C');
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->AliasNbPages();



$archivo_de_salida=$archivo;

// Encabezado de la factura
$pdf->SetFont('Arial','B',14);
$pdf->Cell(190, 10, "FACTURA", 0, 2, "C");
$pdf->SetFont('Arial','B',10);
$pdf->MultiCell(190,5, "Numero de factura: $id_factura"."\n"."Fecha: $fecha_factura", 0, "C", false);
$pdf->Ln(2);

// Consulta a la base de datos para sacar cosas de la factura 1
$c=mysql_connect("localhost","root","");
mysql_select_db("app_recept");

// registro 1 para barco
$orden1="SELECT transporte, nombre_unidad, cantidad, precio, descuento
FROM registros
WHERE  registros.transporte='barco'";
$paquete1=mysql_query($orden1);

//registro 2 para ferrocarril
$orden2="SELECT transporte, nombre_unidad, cantidad, precio
FROM registros
WHERE registros.transporte='ferrocarril'";
$paquete2=mysql_query($orden2);


// Una tabla con las unidade recibidas
// La cabecera de la tabla

$pdf->SetXY(8,60);
$pdf->SetFillColor(135, 206, 250);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(32,10,"Transp",1,0,"C",true);
$pdf->Cell(32,10,"Nom Unid",1,0,"C",true);
$pdf->Cell(32,10,"Cant.",1,0,"C",true);
$pdf->Cell(32,10,"precio",1,0,"C",true);
$pdf->Cell(32,10,"Desc",1,0,"C",true);
$pdf->Cell(32,10,"Subtotal",1,1,"R",true);

$total=0;
$descu=0;

$pdf->SetTextColor(0,0,0);

while($reg1=mysql_fetch_array($paquete1)){
$pdf->SetX(8);
$pdf->Cell(32,10,$reg1[0],1,0,"C");//transporte
$pdf->Cell(32,10,$reg1[1],1,0,"C");//num uni
$pdf->Cell(32,10,$reg1[2],1,0,"C");//cant
$pdf->Cell(32,10,$reg1[3],1,0,"C");//prec
$pdf->Cell(32,10,$reg1[4],1,0,"C");//desc
$pdf->Cell(32,10,$reg1[2]*$reg1[3],1,1,"R");//sub 

$total+=($reg1[2]*$reg1[3]);
$descu+=($total*$reg1[4]/100);
}
// 4º Los totales y demás
$pdf->SetX(135);
$pdf->Cell(32,10,"Subtotal:",1,0,"C");
$pdf->Cell(32,10,number_format($total,2),1,1,"R");
$pdf->SetX(135);
$pdf->Cell(32,10,"Descuento: ",1,0,"C");
$pdf->Cell(32,10,number_format($descu,2),1,1,"R");
$pdf->SetX(135);
$pdf->Cell(32,10,"Total:",1,0,"C");
$pdf->Cell(32,10,number_format($total - $descu,2),1,1,"R");

//Ferrocarril--------------------------------------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>



// La cabecera de la tabla de ferrocarril
$pdf->SetXY(5, 820);
$pdf->SetFillColor(255, 160, 122);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(40,10,"Transporte",1,0,"C",true);
$pdf->Cell(40,10,"Nom Unidad",1,0,"C",true);
$pdf->Cell(40,10,"Cant.",1,0,"C",true);
$pdf->Cell(40,10,"precio",1,0,"C",true);
$pdf->Cell(40,10,"Subtotal",1,1,"C",true);

// Los datos (en negro)
$pdf->SetTextColor(0,0,0);

while($reg2=mysql_fetch_array($paquete2)){
$pdf->SetX(5);
$pdf->Cell(40,10,$reg2[0],1,0,"L");//transporte
$pdf->Cell(40,10,$reg2[1],1,0,"C");//nom unidad
$pdf->Cell(40,10,$reg2[2],1,0,"C");//cant
$pdf->Cell(40,10,$reg2[3],1,0,"C");//precio
$pdf->Cell(40,10,$reg2[2]*$reg2[3],1,1,"R");//sub t
$totall+=($reg2[2]*$reg2[3]);
}
// 4º Los totales y demás
$pdf->SetX(125);
$pdf->Cell(40,10,"Total:",1,0,"C");
$pdf->Cell(40,10,number_format($totall,2),1,1,"R");



$pdf->Output($archivo_de_salida);

//hasta aqui ----------------------------------------------------

//Creacion de las cabeceras que generarán el archivo pdf
header ("Content-Type: application/download");
header ("Content-Disposition: attachmesnt; filename=$archivo");
header("Content-Length: " . filesize("$archivo"));
$fp = fopen($archivo, "r");
fpassthru($fp);
fclose($fp);

//Eliminación del archivo en el servidor
unlink($archivo);

}
