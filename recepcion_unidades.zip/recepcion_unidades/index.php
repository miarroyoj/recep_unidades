

<?php
header("Location: detalle.php");
?>

