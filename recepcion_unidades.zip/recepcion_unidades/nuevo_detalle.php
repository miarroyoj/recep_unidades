<?php
  include "conect/conexion.php";
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Facturar</title>
<style type="text/css">
@import url("css/mycss.css");
</style>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body>
<div class="todo">
  
  <div id="cabecera">
  	
  </div>
  
  <div id="contenido">
  	<div class="form-group " style="margin: auto; width: 800px; border-collapse: separate; border-spacing: 10px 5px;">
  		<span> <h1>Nuevo Registro</h1> </span>
  		<br>
                <form action="nuevo_detalle2.php" method="POST" style="border-collapse: separate; border-spacing: 10px 5px;">
  		
                      <label>Transporte </label>
  		<input class="form-control input-sm" type="text" id="transporte" name="transporte" > (barco o ferrocarril)<br>
  		
                <label>Nom. Unidad </label>
  		<input class="form-control input-sm" type="text" id="nombre_unidad" name="nombre_unidad" ><br>
  		
                <label>Cantidad: </label>
  		<input class="form-control input-sm" type="text" id="cantidad" name="cantidad" ><br>
  		
                <label>Precio ($): </label>
  		<input class="form-control input-sm" type="text" id="precio" name="precio"> $<br>
                
  		<label>Descuento (%): </label>
  		<input class="form-control input-sm" type="text" id="descuento" name="descuento"  > % (solo para barcos)<br>
  		
  		<label>Categoria: </label>
  		<input class="form-control input-sm" type="text" id="categoria" name="categoria" > (contenedor si es barco- vagon si es ferrocarril)<br>
  		
  		<br>
  		<button type="submit" class="btn btn-success">Guardar</button>
     </form>
  	</div>
  	
  </div>
  
	<div id="footer">
  		
  	</div>

</div>


</body>
</html>