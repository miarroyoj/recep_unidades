<?php
	include 'conect/conexion.php';

	NuevoDetalle($_POST['transporte'],$_POST['nombre_unidad'], $_POST['cantidad'], $_POST['precio'], $_POST['descuento'], $_POST['categoria']);

	function NuevoDetalle($trans, $nom_uni, $cant, $prec, $descu, $categ)
	{
		echo $sentencia="INSERT INTO registros (transporte, nombre_unidad, cantidad, precio, descuento ,categoria) VALUES ( '".$trans."','".$nom_uni."','".$cant."','".$prec."', '".$descu."', '".$categ."')";
		mysql_query($sentencia) or die (mysql_error());
	}
?>

<script type="text/javascript">
	alert("Ingresado exitosamente");
	window.location.href='detalle.php';
</script>