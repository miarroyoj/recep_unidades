<?php
	include "conect/conexion.php";

	EliminarDetalle($_GET['id_registro']);

	function EliminarDetalle($id_registro)
	{
		$sentencia="DELETE FROM registros WHERE id_registro='".$id_registro."' ";
		mysql_query($sentencia) or die (mysql_error());
	}
?>

<script type="text/javascript">
	alert("Eliminado exitosamente");
	window.location.href='detalle.php';
</script>